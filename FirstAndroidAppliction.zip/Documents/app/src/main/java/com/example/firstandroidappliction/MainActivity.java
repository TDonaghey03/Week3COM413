package com.example.firstandroidappliction;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Animatable;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public static final Random RANDOM = new Random();
    private ImageView coin;
    private Button btn;
    private Button HeadsPredictor;
    private Button TailsPredictor;
    private TextView scoreTextView;
    private int score = 0;
    private boolean lastFlipWasHeads;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        coin = (ImageView) findViewById(R.id.coin);
        btn = (Button) findViewById(R.id.btn);
        TailsPredictor = (Button) findViewById(R.id.TailsPredictor);
        HeadsPredictor = (Button) findViewById(R.id.HeadsPredictor);
        scoreTextView = findViewById(R.id.scoreTextView);
        updateScore();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flipCoin();
            }
        });

        HeadsPredictor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPrediction(true);
            }
        });

        TailsPredictor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPrediction(false);
            }
        });

    }

    private void incrementScore() {
        score++;
        updateScore();
    }
    private void updateScore() {
        scoreTextView.setText("Score: " + score);
    }

    private void flipCoin() {
        Animation fadeOut = new AlphaAnimation(1, 0);
        fadeOut.setInterpolator(new AccelerateInterpolator());
        fadeOut.setDuration(1000);
        fadeOut.setFillAfter(true);
        fadeOut.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                HeadsPredictor.setEnabled(false);
                TailsPredictor.setEnabled(false);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                lastFlipWasHeads = RANDOM.nextFloat() > 0.5f; // Update this variable
                coin.setImageResource(lastFlipWasHeads ? R.drawable.pound_heads : R.drawable.pound_tails);
                Animation fadeIn = new AlphaAnimation(0, 1);
                fadeIn.setInterpolator(new DecelerateInterpolator());
                fadeIn.setDuration(6000);
                fadeIn.setFillAfter(true);
                coin.startAnimation(fadeIn);
                HeadsPredictor.setEnabled(true); // Re-enable buttons after animation
                TailsPredictor.setEnabled(true);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        coin.startAnimation(fadeOut);

    }

    private void checkPrediction(boolean predictedHeads) {
        if (predictedHeads == lastFlipWasHeads) {
            incrementScore();
        }
    }
}

